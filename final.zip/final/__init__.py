print("""enter your choice number of you want to mathematical operation you want to perform
      1.basic arthematic operations
      2.trignometric operations
      3.hyperbolic functions
      4.logarithms and exponential functions
      5.statistic functions
      or enter 0 to exit the loop""")
p=True
while p==True:
  number=int(input("choice plz:"))
  if number==0:
          p=False
  elif number==1:
        import basic.py
  elif number ==2:
         import trignometry.py
  elif number==3:
         import hyperbola.py
  elif number==4:
         import log.py
  elif number==5:
       import statistics.py
  
  else:
        print("enter the valid number")

