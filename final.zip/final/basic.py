import numpy as np
print("your in the basic arthematic opertions package")
print("""enter the choice plz
          1.basic arthimetic operations
          2.scalar operations""")
choice=int(input("enter the choice:"))
if choice==1:
    count=0
    x=2
    num=int(input("enter the numberof elements you need in the array: "))
    for k in range(x):
      a=[]
      if num>0:
         for i in range(num):
           n=int(input("enter the element of the array:"))
           a.append(n)
           print(a)
         count+=1
         if count==1:
             arr1=np.array(a)
             print("arr1=",arr1)
         else:
             arr2=np.array(a)
             print("arr2=",arr2)
      else:
        print("valid number plz")
       # creating the class and defining the functions

    class simple_math:
             def add(n,u):
                   n=arr1
                   u=arr2
                   value=np.add(arr1,arr2)
                   print("the value of adding 2 arrays",n,u,"is ", value)
             def subtract(n,u):
                n=arr1
                u=arr2
                value=np.subtract(arr1,arr2)
                print("the the difference between 2 arrays",n,u,"is ", value)
             def multiply(n,u):
                n=arr1
                u=arr2
                value=np.multiply(arr1,arr2)
                print("the value of multiplying 2 arrays",n,u,"is ", value)
             def divide(n,u):
                n=arr1
                u=arr2
                value=np.divide(arr1,arr2)
                print("the value of dividing 2 arrays",n,u,"is ", value)
             def mod(n,u):
                n=arr1
                u=arr2
                value=np.mod(arr1,arr2)
                print("the remainders of diving 2 arrays",n,u,"is ", value)
             def divmod(n,u):
                n=arr1
                u=arr2
                value=np.divmod(arr1,arr2)
                print("the remainder and quotient of 2 arrays",n,u,"is ", value)
             def power(n,u):
                n=arr1
                u=arr2
                value=np.power(arr1,arr2)
                print("the power 2 arrays",n,u,"is ", value)
             def positive(n):
                for i in range(2):
                    if i==0:
                        n=arr1
                        value1=np.positive(arr1)
                        print("the positive values of  1st array",arr1,"is ", value1)
                    else:
                       n=arr2
                       value2=np.positive(arr2)
                       print("the positive values of  2 nd array",arr2,"is ",value2)
             def negative(n):
                for i in range(2):
                    if i==0:
                        n=arr1
                        value1=np.negative(arr1)
                        print("the negative values of  1st array",arr1,"is ", value1)
                    else:
                       n=arr2
                       value2=np.negative(arr2)
                       print("the negative values of  2nd array",arr2,"is ", value1)
            
    print("""enter your choice you want to
      1addition
      2.subtraction
      3.multiplication
      4.division
      5.remainder
      6.both remainder and quotient
      7.power
      8.positive
      9.negative
      or enter 0 to exit the loop""")
    p=True
    while p==True:
              number=int(input("choice plz:"))
              if number==0:
                 p=False
              elif number==1:
                 s1=simple_math.add(arr1,arr2)
              elif number ==2:
                 s1=simple_math.subtract(arr1,arr2)
              elif number==3:
                   s1=simple_math.multiply(arr1,arr2)
              elif number==4:
                   s1=simple_math.divide(arr1,arr2)
              elif number==5:
                   s1=simple_math.mod(arr1,arr2)
              elif number==6:
                   s1=simple_math.divmod(arr1,arr2)
              elif number==7:
                   s1=simple_math.power(arr1,arr2)
              elif number==8:
                   t=int(input("enter 1 or 0 to exit"))
                   if t==1:
                      s1=simple_math.positive(arr1)
                   else:
                      s1=simple_math.positive(arr2)
              elif number==9:
                   if t==1:
                      s1=simple_math.negative(arr1)
                   else:
                       s1=simple_math.negative(arr2)
              else:
                  print("enter the valid number")
    
        
          
elif choice==2:
    R = int(input("Enter the number of rows:")) 
    C = int(input("Enter the number of columns:"))
    count=0
    x=2
    for k in range(x):
        matrix =[]
        if count==0:
          print("Enter the entries rowwise:") 
          for i in range(R):          
                a =[] 
                for j in range(C):       
                   a.append(int(input())) 
                matrix.append(a)
          for i in range(R): 
               for j in range(C): 
                  print(matrix[i][j], end = " ")
               print()
               m1=matrix
          count+=1
        else:
            print("Enter the entries rowwise:") 
            for i in range(R):          
                a =[] 
                for j in range(C):       
                   a.append(int(input())) 
                matrix.append(a)
            for i in range(R): 
               for j in range(C): 
                  print(matrix[i][j], end = " ")
               print()
               m2=matrix
    print("matrix=",m1)
    print("matrix1=",m2)
    
    class scalar:
           
           def mult(n):
                for i in range(2):
                    n=int(input("enter the number"))
                    if i==0:
                        value1=m1*n
                        print("the multiplied values of  matrix with",m1,"are", value1)
                    else:
                       value2=m2*n
                       print("the multiplied values of matrix with ",m2,"is ",value2)
    
           
           
           def dot(n,u):
              n=m1
              u=m2
              value =np.dot(m1,m2)
              print("the  dot product value of " ,n,u," is ",value)
           def cross(n,u):
              n=m1
              u=m2
              value =np.cross(m1,m2)
              print("the  cross product value of ",n,u," is",value)
 
           

    print("""enter your choice you want to
      1.scalar multiplication
      
      2. dot product
      3. cross product
      or enter 0 to exit the loop""")
    p=True
    while p==True:
              number=int(input("choice plz:"))
              if number==0:
                 p=False
              
              elif number ==1:
                   t=int(input("enter 1 or 0 to exit"))
                   if t==1:
                      s1=scalar.mult(m1)
                   else:
                      s1=scalar.mult(m2)
              
              
              elif number==2:
                   s1=scalar.dot(m1,m2)
              elif number==3:
                   s1=scalar.cross(m1,m2)
              
else:
    print("valid number plz")
       
    
           
