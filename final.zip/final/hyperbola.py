import numpy as np
print("your in the hyperbola module")
R = int(input("Enter the number of rows:")) 
C = int(input("Enter the number of columns:")) 
matrix = [] 
print("Enter the entries rowwise:") 
for i in range(R):          
    a =[] 
    for j in range(C):       
         a.append(int(input())) 
    matrix.append(a) 
arr=matrix
               #creating hyperbola class
    
class hyperbola:
   def sinh(n):
        n=arr
        value=np.sinh(n)
        print("the value of sin(",n,") is ", value)
   def cosh(n):
        value=np.cosh(n)
        print("the value of cos(",n,") is ", value)
    
   def tanh(n):
        value=np.tanh(n)
        print("the value of tan(",n,") is ", value)
   def arcsinh(n):
       value=np.arcsinh(n)
       print(" the value of arcsinh(",n,") is ",value)
   def arccosh(n):
       value =np.arccosh(n)
       print("the value of arccosh(" ,n,") is ",value)
   def arctanh(n):
       value =np.arctanh(n)
       print("the value of arctanh(",n,") is",value)
 
print("""enter your choice you want to
      1.sin fun
      2.cos fun
      3.tan fun
      4.arcsinh
      5.arccosh
      6.arctanh
      or enter 0 to exit the loop""")
p=True
while p==True:
  number=int(input("choice plz:"))
  if number==0:
          p=False
  elif number==1:
         s1=hyperbola.sinh(arr)
  elif number ==2:
          s1=hyperbola.cosh(arr)
  elif number==3:
        s1=hyperbola.tanh(arr)
  elif number==4:
        s1=hyperbola.arcsinh(arr)
  elif number==5:
       s1=hyperbola.arccosh(arr)
  elif number==6:
      s1=hyperbola.arctanh(arr)
  else:
        print("enter the valid number")
