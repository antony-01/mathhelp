import numpy as np
print("your in the logarithm and exponential  module")

   # creating an matrix to perform the operations

print("create your matrix")   
R = int(input("Enter the number of rows:")) 
C = int(input("Enter the number of columns:")) 
matrix = [] 
print("Enter the entries rowwise:") 
for i in range(R):          
    a =[] 
    for j in range(C):       
         a.append(int(input())) 
    matrix.append(a)
for i in range(R): 
    for j in range(C): 
        print(matrix[i][j], end = " ") 
    print() 
arr=matrix

       # creating the class for logarithm and exponential

       
class log_exp:
    def log(n):
        n=arr
        value=np.log(n)
        print("the value of log",n,"is ", value)
    def log10(n):
        value=np.log10(n)
        print("the value of log10 of ",n," is ", value)
    
    def log2(n):
        value=np.log2(n)
        print("the value of log2 of ",n,"is ", value)
    def exp(n):
       value=np.exp(n)
       print(" the exponent values of ",n,"are ",value)
    def exp2(n):
       value =np.exp2(n)
       print("the exponent2 values of " ,n,"are ",value)
    def sqrt(n):
       value =np.sqrt(n)
       print("the square root values of",n,"are",value)
    def log1p(n):
        value=np.log1p(n)
        print("the  values of logp1 of",n,"are",value)

        #printing the list of operations
        
print("""enter your choice you want to
      1.log fun
      2.log10 fun
      3.log2 fun
      4.exponential values
      5.exponent of 2 
      6.square root values
      7.log1p 
      or enter 0 to exit the loop""")

        # creating the objects

      
p=True
while p==True:
  number=int(input("choice plz:"))
  if number==0:
          p=False
          print("your out of the loop")
  elif number==1:
         s1=log_exp.log(arr)
  elif number ==2:
          s1=log_exp.log10(arr)
  elif number==3:
        s1=log_exp.log2(arr)
  elif number==4:
        s1=log_exp.exp(arr)
  elif number==5:
       s1=log_exp.exp2(arr)
  elif number==6:
      s1=log_exp.sqrt(arr)
  elif number==7:
       s1=log_exp.log1p(arr)
  
  else:
        print("enter the valid number")


