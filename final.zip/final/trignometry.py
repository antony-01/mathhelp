import numpy as np
print("your in the trignometry  module")
             # creating an array
R = int(input("Enter the number of rows:")) 
C = int(input("Enter the number of columns:")) 
matrix = [] 
print("Enter the entries rowwise:") 
for i in range(R):          
    a =[] 
    for j in range(C):       
         a.append(int(input())) 
    matrix.append(a) 
arr=matrix

class trignometric_fun:
      def sin(n):
         n=arr
         value=np.sin(n)
         print("the values of sin(",n,") is ", value)
      def cos(n):
          n=arr
          value=np.cos(n)
          print("the values of cos(",n,") is ", value)
      def tan(n):
        n=arr
        value=np.tan(n)
        print("the value of tan(",n,") is ", value)
         
      def arcsin(n):
          n=arr
          value=np.arcsin(n)
          print(" the values of arcsin(",n,") is ",value)
      def arccos(n):
          n=arr
          value =np.arccos(n)
          print("the values of arccos(" ,n,") is ",value)
      def arctan(n):
          n=arr
          value =np.arctan(n)
          print("the values of arctan(",n,") is",value)
class rad_deg:
       def radians(n):
          n=arr
          value=np.radians(n)
          print("the values of radians(",n,") is",value)
       def degrees(n):
           n=arr
           value=np.degrees(n)
           print("the values of degrees(",n,")is",value)
       def rad2deg(n):
          n=arr
          value=np.rad2deg(n)
          print("the values of rad2deg(",n,") is ",value)
       def deg2rad(n):
           n=arr
           value=np.deg2rad(n)
           print("the values of drg2rad(",n,") is ",value)
       def around(n,decimal):
          n=arr
          value=np.around(n,decimal)
          print("the values of around(",n,")is",value)
       def floor(n):
          n=arr
          value=np.floor(n)
          print("the values of floor(",n,") is",value)
       def ceil(n):
          n=arr
          value=np.ceil(n)
          print("the values of ceil(",n,") is " ,value)
print(''' select the operation you want from below
          1.trignometric functions
          2.radians and degree''')
x=int(input("enter the choice"))

if x==1:
    
      print("""enter your choice you want to
            1.sin fun
            2.cos fun
            3.tan fun
            4.arcsin
            5.arccos
            6.arctan
           or enter 0 to exit the loop""")
      p=True
      while p==True:
         number=int(input("choice plz:"))
         if number==0:
            p=False
            print("you're out of the loop now")
         elif number==1:
            s1=trignometric_fun.sin(arr)
         elif number ==2:
            s1=trignometric_fun.cos(arr)
         elif number==3:
            s1=trignometric_fun.tan(arr)
         elif number==4:
            s1=trignometric_fun.arcsin(arr)
         elif number==5:
            s1=trignometric_fun.arccos(arr)
         elif number==6:
           s1=trignometric_fun.arctan(arr)
         else:
           print("enter the valid number")
if x==2:
       print(""" enter the choice you need to covert
           1.to radians
           2.to degrees
           3.rad2deg
           4.deg2rad
           5.around
           6.floor
           7.ceil or enter 0 to exit""")
       p=True
       while p==True:
            number=int(input("choice plz:"))
            if number==0:
               p=False
               print("you're out of the loop")
            elif number==1:
               s1=rad_deg.radians(arr)
            elif number ==2:
                s1=rad_deg.degrees(arr)
            elif number==3:
                s1=rad_deg.rad2deg(arr)
            elif number==4:
                s1=rad_deg.deg2rad(arr)
            elif number==5:
                decimal=int(input("enter the decimal"))
                s1=rad_deg.around(arr,decimal)
            elif number==6:
                s1=rad_deg.floor(arr)
            elif number==7:
                s1=rad_deg.ceil(arr)
            else:
                print("enter the valid number")
        
else:
       print ("enter valid number pls")

