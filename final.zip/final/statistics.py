import numpy as np
print("your in the statistics module")

R = int(input("Enter the number of rows:")) 
C = int(input("Enter the number of columns:")) 
matrix = [] 
print("Enter the entries rowwise:") 
for i in range(R):          
    a =[] 
    for j in range(C):       
         a.append(int(input())) 
    matrix.append(a)
for i in range(R): 
    for j in range(C): 
        print(matrix[i][j], end = " ") 
    print() 
arr=matrix

class statistics:
    def mean(n,axis):
        n=arr
        if axis==99:
           value=np.mean(n)
           print("the mean values of",n,"are",value)
        else:
            value=np.mean(n,axis)
            print("the mean values of",n,"are",value)
    def average(n,axis):
        n=arr
        if axis==99:
           value=np.average(n)
           print("the avarage values of ",n," are", value)
        else:
            value=np.average(n,axis)
            print("the average values of",n,"are",value)
    def median(n,axis):
        n=arr
        if axis==99:
           value=np.median(n)
           print("the  median values of ",n," are ", value)
        else:
            value=np.median(n,axis)
            print("the median values of",n,"are",value)
    
    def variable(n):
        n=arr
        value=np.var(n)
        print("the values of variable",n,"are ", value)
    def amin(n,axis):
        n=arr
        if axis==99:
           value=np.amin(n)
           print(" the   minimum value of",n," are",value)
        else:
            value=np.amin(n,axis)
            print("the minimum values of",n,"are",value)
    def amax(n,axis):
        n=arr
        if axis==99:
           value =np.amax(n)
           print("the maximum values of " ,n,") is ",value)
        else:
            value=np.amax(n,axis)
            print("the maximun values of",n,"are",value)
    def ptp(n,axis):
        n=arr
        if axis==99:
          value =np.ptp(n)
          print("the ptp values of",n,"are",value)
        else:
            value=np.ptp(n,axis)
            print("the ptp values of",n,"are",value)
    def std(n):
        n=arr
        value=np.std(n)
        print("the standard deviation values of",n,"are",value)
    def percentile(n,q,axis):
        n=arr
        if axis==99:
            value=np.percentile(a,q)
            print("the percentile of",n,"are",value)
        else:
            value=np.percentile(a,q,axis)
            print("the percentile of",n,"are",value)
            
   # creating the objects         
print("""enter your choice you want to
      1.mean
      2.average
      3.median
      4.varaible
      5.minimum
      6.maximum
      7.ptp
      8.standard deviation
      9.percentile
      or enter 0 to exit the loop""")
p=True
while p==True:
  number=int(input("choice plz:"))
  if number==0:
          p=False
  elif number==1:
         axis=int(input("enter the axis or none"))
         if axis <=R:
            s1=statistics.mean(arr,axis)
         else:
             print("you're axis is beyond the rows")
  elif number ==2:
          axis=int(input("enter the axis or none"))
          if axis <=R:
             s1=statistics.average(arr,axis)
          else:
             print("you're axis is beyond the rows")
  elif number==3:
         axis=int(input("enter the axis or none"))
         if axis <=R:
            s1=statistics.median(arr,axis)
         else:
             print("you're axis is beyond the rows")
  elif number==4:
         s1=statistics.variable(arr)
  elif number==5:
       axis=int(input("enter the axis or none"))
       if axis <=R:
          s1=statistics.amin(arr,axis)
       else:
             print("you're axis is beyond the rows")
  elif number==6:
         axis=int(input("enter the axis or none"))
         if axis <=R:
            s1=statistics.amax(arr,axis)
         else:
             print("you're axis is beyond the rows")
  elif number==7:
         axis=int(input("enter the axis or none"))
         if axis <=R:
            s1=statistics.ptp(arr,axis)
         else:
             print("you're axis is beyond the rows")
  elif number==8:
         s1=statistics.std(arr)
  elif number==9:
         q=int(input("enter the percentilt"))
         axis=int(input("enter the axis or none"))
         if axis <=R:
            s1=statistics.percentile(arr,q,axis)
         else:
             print("you're axis is beyond the rows")
  else:
        print("enter the valid number")

       
          
      
